<?php
include_once("./SDK/WeChatController.class.php");
include_once("./SDK/HttpClient.php");

// $weixin = new WeChatController(FALSE);
// $access_token = $weixin->get_access_token();
$access_token = "5rtio6zUpAEzthRiSAhkyURVSd5ZjxcTTwSrahe977j6nmjGt6vNuq0quHYFT8Wt1y7W034hKWGXhV-6m3SKsTGBqYUssoUTyoKV9aBX4b2SXypShLj_8yGb1c0rY8YjCYPdAHAKGX";
echo "ACCESS TOKEN:<br>".$access_token."<br>";

$type = "image";
$url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=".$access_token."&type=".$type;
echo "URL:<br>".$url."<br>";


$dir = "/home/web/weixin/src/pics/";
$file = "sjtu.png";
$media = array('media' => "@".$dir.$file, 'wx' => "none");

echo "MEDIA:<br>";
var_dump($media);
echo "<br>";



// "media=@".$dir.$file."\r\n"
$res = HttpClient::curl_post($url, implode("\r\n", $media));
var_dump($res);

$ref = array("asuna.jpg" => "xu63t1qfxWlwYecxmkGv0k_XiZ17FQO1avhSMiUSRJ1QleN0mGg5jG5fbqdPQi5q", "mikoto.jpg" => "jVYpsyRgxf7u5l4FYm73sJ-Q0iG1wys6cF8_phAisAVbO243B0Ii7Q87VNltO69i");



