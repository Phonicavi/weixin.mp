<?php

/**
* WeChatConfig: configurations
*/
class WeChatConfig
{
	// APP Info
	const APPID = "wxf36651270f0fd5c3";
	const APPSECRET = "40d930eda68fd69431326d61e2acd3db";
	const TOKEN = "phonicavi";

	// Log-files PATH
	const PATH_LOGGING = "/home/web/weixin/logs/";

	// other API
	const API = '';
}
